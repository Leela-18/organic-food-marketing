from django.urls import path
from FOOD import views

urlpatterns = [
    path('about',views.about,name='about'),
    path('bolg',views.blog,name='blog'),
    path('contact',views.contact,name='contact'),
    path('feature',views.feature,name='feature'),
    path('product',views.product,name='product'),
    path('testinomial',views.testimonial,name='testinomial'),
    path('index',views.index,name='index'),
    path('service',views.service,name='service'),
    path('team',views.team,name='team'),
    path('detail',views.detail,name='detail'),
    
]
    
