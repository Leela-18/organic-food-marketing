from django.shortcuts import render

# Create your views here.
def about(request):
    return render(request,'FOOD/about.html')
def blog(request):
    return render(request,'FOOD/blog.html')
def contact(request):
    return render(request,'FOOD/contact.html')
def feature(request):
    return render(request,'FOOD/feature.html')
def product(request):
    return render(request,'FOOD/product.html')
def testimonial(request):
    return render(request,'FOOD/testimonial.html')
def index(request):
    return render(request,'FOOD/index.html') 
def detail(request):
    return render(request,'FOOD/detail.html')
def service(request):
    return render(request,'FOOD/service.html')
def team(request):
    return render(request,'FOOD/team.html')
